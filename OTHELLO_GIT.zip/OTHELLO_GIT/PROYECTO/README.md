﻿Proyecto del grupo 5 de Sistemas Operativos (2022-23-Q1)
OTHELLO
Version generada por Alejandro.
Version verificada por Carla y Marina.
Version 1 Comunicada por Laura 
URL video --> https://youtu.be/XMLqMb9jxj0

VersionConConexionDesconexion

------------------VERSION 2------------------------

Version 2 generada por Laura

Version 2 verificada por Alejandro

Version 2 comunicada por Marina

url: https://www.youtube.com/watch?v=xths7epSUhY 

------------------VERSION 3------------------------

Version 3 generada por Marina

Versión 3 verificada por Alejandro

Version 3 comunicada por Carla

URL: https://youtu.be/QMrkwTPNam8

-----------------------------------------------------